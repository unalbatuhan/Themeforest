<?php
$coder_current_path = plugin_dir_path( __FILE__ );
require_once trailingslashit( $coder_current_path ) . '/functions/get-all-values.php';
require_once trailingslashit( $coder_current_path ) . '/functions/get-single-value.php';